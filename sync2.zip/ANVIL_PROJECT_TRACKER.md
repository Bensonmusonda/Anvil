
# Anvil Editor — Project Tracker

A living companion to `Anvil_Editor_Specification_v2.docx`. Update this file as you work — it's meant to get messy and current, not stay polished. The spec is the "what and why"; this is the "where are we now."

---

## 1. Phase Checklist

Check items off as they're _verifiably_ done (exit criteria met), not just started.

### Phase 0 — Skeleton

- [x] `create-tauri-app` scaffold running
- [x] Blank CodeMirror 6 instance rendering in the webview
- [x] One round-trip IPC message (frontend → Rust → frontend)

### Phase 1 — Backend Routing Prototype

- [x] Config parser reads and validates the provider/routing schema
- [x] Ollama proxy bridge working
- [x] DeepSeek proxy bridge working
- [ ] OpenRouter proxy bridge working
- [x] stdin/stdout agent script loop operational
- [x] `curl`/CLI test returns real completions from ≥2 providers

### Phase 2 — Text Surface Assembly

- [x] Tauri UI workspace shell built
- [x] CodeMirror instance wired to filesystem reads
- [x] File tree navigation working
- [x] Syntax highlighting via `@codemirror/lang-*` for target languages
- [x] Can open and browse a real project directory

### Phase 3 — Dual-Process Wiring

- [x] Client↔daemon communication loop bound
- [x] AI generation output reaches the editor view
- [x] Filesystem watcher (`notify`) firing IPC invalidation signals
- [x] `.anvil/history/` snapshot-on-mutation working
- [x] Revert-to-snapshot working
- [x] Commit (clear history) working

### Phase 4 — Tool Registry + MCP Host

- [x] `read_file` tool implemented natively
- [x] `write_file` tool implemented natively
- [x] Tool Registry Service exposing declarative JSON schemas
- [x] MCP Host built on official MCP SDK
- [x] ≥1 real external MCP server connected and callable
- [x] Agent completes a task mixing a built-in tool + an MCP tool

### Phase 5 — LSP Integration

- [x] Daemon can spawn a language server per project language
- [x] LSP JSON-RPC proxied to frontend
- [x] Autocomplete via LSP working
- [x] Go-to-definition / references working
- [x] Inline diagnostics working
- [x] Hover documentation working

### Phase 6 — Polish

- [ ] Integrated terminal (`portable-pty` + `xterm.js`)
- [ ] Git panel (status/stage/commit/diff)
- [ ] Fuzzy file/command finder (`nucleo`)
- [ ] Theming (config-driven, no rebuild)
- [ ] Used as daily driver on one real project

---

## 2. Locked Decisions

Record decisions once made so they don't get silently re-litigated later.

| Date       | Decision                                                                                                     | Rationale                                                                                                                   | Status                |
| ---------- | ------------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------- | --------------------- |
|            | Daemon language: Rust vs Go                                                                                  |                                                                                                                             | ⬜ Open                |
|            | v1 extension format = MCP servers only                                                                       | Avoids designing a second plugin format before one is needed                                                                | ✅ Proposed in spec §8 |
|            | Telemetry/crash reporting: none / opt-in                                                                     |                                                                                                                             | ⬜ Open                |
| 2026-07-05 | fold daemon into src-tauri instead of separate OS process                                                    |                                                                                                                             |                       |
| 2026-07-05 | Used `gpt-oss:20b-cloud`for the phase 4 tests                                                                | Excels at tool calling                                                                                                      |                       |
| 2026-07-06 | LSP transport: hand-rolled Content-Length JSON-RPC framing (no wrapper crate)                                | Protocol is small, stable, well-documented — not worth a dependency for it                                                  | ✅ Locked              |
| 2026-07-06 | Phase 5 supports rust-analyzer only; other languages deferred                                                | Matches incremental, one-thing-verified-at-a-time approach used every phase so far                                          | ✅ Locked              |
| 2026-07-06 | lsp_request unwraps the JSON-RPC envelope and returns only the inner `result` to the frontend                | Original version returned the full envelope, causing hover/completion/definition to silently return empty — see Gotchas Log | ✅ Locked              |
| 2026-07-06 | Active development moved from Claude-authored file edits to Antigravity IDE, with Claude as reviewer/advisor | Context between chat and on-disk code had drifted; safer to have one tool actually touching files                           | ✅ Locked              |

---

## 3. Open Questions / Risks

Pull these from spec §11 and add new ones as they surface. Move to "Locked Decisions" once resolved.

- [ ] Rust vs. Go for the daemon — decide before Phase 1 starts
- [ ] LSP process lifecycle (spawn/restart/kill) strategy
- [ ] Frontend-contributed UI extension points — separate design effort if ever pursued
- [ ] Minimum viable local hardware spec for Ollama-based inline completion
- [ ] Telemetry/crash reporting stance

---

## 4. Dependency / Version Log

Track exact versions once chosen, so "it worked on my machine" has a paper trail.

|Component|Package/Crate|Version Pinned|Notes|
|---|---|---|---|
|App shell|Tauri|||
|Editor|CodeMirror|6.x||
|Filesystem watch|notify||Rust crate|
|Diffing|similar||Rust crate|
|Git|git2 / system git|||
|Fuzzy search|nucleo|||
|Terminal backend|portable-pty|||
|Terminal frontend|xterm.js|||
|MCP|official MCP SDK||Rust or TS|
|HTTP/streaming|reqwest + eventsource-stream|||

---

## 5. Session Log

One line per work session. Keeps momentum visible and makes it easy to pick up after a break.

```
YYYY-MM-DD — What I worked on — What's next
```

- 2026-07-04 — Refined project spec (v2), added Phase 0 and Phase 5, drafted OSS adoption table — Start Phase 0 scaffold
- 2026-07-05 — Phase 3 complete: AI-in-editor, watcher, snapshot/revert/commit all verified — Start Phase 4
- 2026-07-06 — Phase 5 complete: rust-analyzer wired in (Content-Length JSON-RPC relay), all four features (autocomplete, hover, go-to-def, diagnostics) verified against a real project with external deps (clap, anyhow). Root cause of the hover/completion/definition bug found by Antigravity (JSON-RPC envelope not unwrapped) after Claude misdiagnosed it as a workspace-loading issue. Switched active development to Antigravity IDE going forward; Claude's role shifts to review/advisory to avoid drift between chat context and on-disk code. — Next: scope Phase 6 (Polish)

---

## 6. Parked Ideas (Not in Spec)

Ideas worth remembering but deliberately not committed to yet — revisit when the trigger condition is met, don't build toward them before then.

| Idea                                                                   | Why not now                                                                                                                                                                                        | Revisit when                                                                                                                                                                                                                                                                |
| ---------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Fine-tune a model on Anvil's architecture + extension-writing patterns | Architecture is still pre-Phase-0 and will shift; no real corpus of correct extensions exists yet to train on; adds a training/eval/hosting pipeline that cuts against the low-overhead philosophy | A dozen+ real, working extensions exist and the tool-registry/API surface has settled. Until then, get the same benefit cheaply via context-priming (spec + example extensions fed to a general-purpose model in an "extension-authoring mode") rather than a training run. |

---
## 7. Git Workflow

One short-lived branch per phase (or sub-task within a phase). `main` always stays in a working state.

**Per phase:**
```bash
git checkout -b phase-N-name
# commit as you go
git add .
git commit -m "..."
```

**When exit criteria are actually met (not just "seems done"):**
```bash
git checkout main
git merge phase-N-name
git tag phase-N-complete
git branch -d phase-N-name
```

**Habit:** commit *before* starting a hard bug fix, not after — gives a clean diff and an escape hatch (`git checkout .`) if the fix makes things worse.

**Push:**
```bash
git push -u origin main --tags
```

---
## 8. Gotchas Log

Non-obvious, environment-specific lessons worth remembering — the kind of thing that looks like a new bug but isn't.

| Date       | Symptom                                                                                                                    | Root Cause                                                                                                                                                                                                         | Fix                                                                                                                |
| ---------- | -------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------ |
| 2026-07-05 | External file edits didn't trigger a reload in the editor                                                                  | `notify` watcher only matched `Modify`/`Create`/`Remove` events — editors that save atomically (write temp file, rename over original) can emit events that don't cleanly match that filter                        | Broadened the watcher's event filter to accept everything except pure `Access` events                              |
| 2026-07-05 | `window.__TAURI__.event.listen` threw "not allowed" despite `withGlobalTauri: true`                                        | Tauri v2's capability/permission system gates its own `core:event` API — this is separate from custom `#[tauri::command]`s, which are *not* capability-gated                                                       | Added `src-tauri/capabilities/default.json` granting `core:event:default` / `core:event:allow-listen`              |
| 2026-07-05 | Model narrates instead of calling                                                                                          | Looks like a code bug but is actually a model-capability tell, and easy to misdiagnose next time a different local model gets tried.                                                                               | Switched from a local `llama3.2-local:latest` model to a cloud `gpt-oss:20b-cloud` on Ollama                       |
| 2026-07-06 | `rust-analyzer` reported "Unknown binary" despite `which rust-analyzer` finding something                                  | rustup installs a proxy binary on PATH regardless of whether the actual component is installed — `which` confirms existence, not that it works                                                                     | `rustup component add rust-analyzer`                                                                               |
| 2026-07-06 | rust-analyzer logged `ERROR duplicate DidOpenTextDocument`                                                                 | Re-opening an already-open file resent `didOpen` without a `didClose` first — a real LSP protocol violation                                                                                                        | Track currently-open path; send `didClose` before switching files, skip re-sending `didOpen` for the same file     |
| 2026-07-06 | Only one LSP message (`workspace/diagnostic/refresh`) ever appeared in logs; no indexing progress                          | That message is a server-initiated *request* (has an `id`), not a notification — our relay only replied to responses to requests *we* sent, never acknowledged server-initiated ones, so a strict server may stall | Acknowledge any message with an unrecognized `id` + a `method` field with a null-result response                   |
| 2026-07-06 | Hover/completion/definition all silently returned empty even on a fully-loaded workspace (confirmed via raw devtools test) | `lsp_request` returned the full JSON-RPC envelope (`{jsonrpc, id, result}`), but every frontend handler read fields as if `result` were the top level                                                              | Unwrap `result` before returning from `lsp_request` (found and fixed by Antigravity, not Claude)                   |
| 2026-07-06 | Autocomplete showed real but oddly-ordered/unranked suggestions                                                            | CodeMirror's own fuzzy matcher was re-scoring completions, discarding rust-analyzer's `sortText` relevance ordering; all items also showed as generic type due to unmapped LSP `kind`                              | Sort by `sortText` before returning to CM6, apply descending `boost`, map LSP `kind` codes to CM6 completion types |

---
## 9. Milestone Targets

Fill in once you have a rough calendar in mind — these are placeholders.

| Milestone                    | Target Date | Actual Date |
| ---------------------------- | ----------- | ----------- |
| Phase 0 complete             |             |             |
| Phase 1 complete             |             |             |
| Phase 2 complete             |             |             |
| Phase 3 complete             |             |             |
| Phase 4 complete             |             |             |
| Phase 5 complete             |             |             |
| Phase 6 / daily-driver ready |             |             |
